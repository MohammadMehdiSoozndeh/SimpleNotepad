package com.example.nabztechandroidinternship2;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

import java.util.List;

import io.reactivex.Flowable;

public class NoteViewModel extends AndroidViewModel {

    private NoteDatabase noteDatabase;

    public NoteViewModel(@NonNull Application application) {
        super(application);
        noteDatabase = NoteDatabase.getInstance(application);
    }

    Flowable<List<Note>> getList() {
        return noteDatabase.noteDao().getNoteList();
    }

    long addData(Note note) {
        return noteDatabase.noteDao().insertNote(note);
    }

    int updateData(Note note) {
        return noteDatabase.noteDao().updateNote(note);
    }

    int deleteData(Note note) {
        return noteDatabase.noteDao().deleteNote(note);
    }

}
