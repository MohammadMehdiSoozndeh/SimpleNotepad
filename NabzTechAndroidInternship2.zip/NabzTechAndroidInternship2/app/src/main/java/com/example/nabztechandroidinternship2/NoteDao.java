package com.example.nabztechandroidinternship2;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import io.reactivex.Flowable;

@Dao
public interface NoteDao {

    @Query("Select * from notebook")
    Flowable<List<Note>> getNoteList();

    @Insert
    long insertNote(Note note);

    @Update
    int updateNote(Note note);

    @Delete
    int deleteNote(Note note);

}
